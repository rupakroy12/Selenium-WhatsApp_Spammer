Whatsapp spammer script 
Author : Rupak Roy
Contact number : 8777499303

Steps to run :

|-> Double click on run.bat
|-> Command prompt opens
|-> Google chrome opens whatsapp web
|-> Scan qr code to login to whatsapp web.
|-> Manually open the contact you want to spam on the browser
|-> After the contact is opened follow command prompt to spam that contact.